<?php


namespace App;


class Filter {
    private $filter_data;

    public function __construct($request) {
        $country = (array)$request->country;
        $city = (array)$request->city;
        $price = (array)$request->price;
        $duration = (array)$request->duration;
        $this->filter_data = ['country'=>$country, 'city'=>$city, 'price'=>$price, 'duration'=>$duration];
    }

    public function getFilterData() {
//        foreach ($this->filter_data as $data) {
//            if (is_array($data)) {
//                foreach ($data as $item) {
//                    echo "$item   ";
//                }
//            } else {
//                echo "$data,   ";
//            }
//        }
        return $this->filter_data;
    }

}
