<?php


namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Product;
use App\Type;
use Illuminate\Http\Request;
use App\Pages;
use App\UsersRegistration;



class PageController extends Controller{
    public function getPages($page, $lib) {
        $page = new Pages($page, $lib);
        return view('index', ['page' => $page]);
    }

    public function postUsersData(Request $request) {
        $user = new UsersRegistration($request);
        return view('index', ['user'=>$user]);
    }

//    public function DB(Request $request) {
//        $name = $request->country;
//        if (isset($name)) {
//
//            foreach ($name as $n) {
//                echo $n;
//            }
//        }
//    }
}
