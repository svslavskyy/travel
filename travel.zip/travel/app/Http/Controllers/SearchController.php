<?php


namespace App\Http\Controllers;


use App\Filter;
use App\Http\Controllers\Controller;
use App\Option;
use App\Type;
use Illuminate\Http\Request;
use App\Pages;
use App\UsersRegistration;


class SearchController extends Controller {
    public function getPagesSome(Request $request) {
        $page = new Pages();
//        $name = $request->country;
//        if (isset($name)) {
//
//            foreach ($name as $n) {
//                echo $n;
//            }
//        }
        $filter = new Filter($request);
        return view('index', ['page' => $page, 'filter' => $filter->getFilterData()]);
    }
//    public function getPagesOption($page, $lib, $shop_option = 0) {
//        $s = new Pages($page, $lib);
//        return view('index', ['obj' => $s, 'options' => Option::all(), 'shop_option' => $shop_option]);
//    }
}
