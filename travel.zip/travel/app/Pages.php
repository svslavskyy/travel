<?php


namespace App;



class Pages {
    public $page;
    public $lib;
    public function __construct($page='searching', $lib='searching') {
        $this->page = $page;
        $this->lib = $lib;
    }
}
