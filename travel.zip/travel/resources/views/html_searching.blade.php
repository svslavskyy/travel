<div class="body">
    <div class="why">
        <h4>Пошук турів</h4>
        <div class="why_text">
            <div class="left_small">
                <button class="left_small_filter">Фільтр</button>
                <button class="left_small_cancel">Очистити</button>
            </div>
            <div class="left">
                <h5>Фільтр</h5>
                @yield('filter_left')
            </div>


            <div class="right">
                @yield('filter_check')
                <div class="right_tour">
                    <div class="tour">
                        <div class="tour_block_items">
                            <div class="tour_item">
                                <div class="item_image">
                                    <img src="../img/169.jpg"/>
                                    <div class="item_image_text">
                                        <div>
                                            <p class="item_p_1">
                                                10 300 грн
                                            </p>
                                            <p class="item_p_2">
                                                за 1 особу
                                            </p>
                                        </div>
                                        <button>
                                            Детальніше
                                        </button>
                                    </div>
                                </div>
                                <div class="item_info">
                                    <p class="item_info_p_1">
                                        Seazone Hotel
                                    </p>
                                    <p class="item_info_p_2">
                                        Украина , Затока
                                    </p>
                                </div>
                            </div>
                            <div class="tour_item">
                                <div class="item_image">
                                    <img src="../img/169.jpg"/>
                                    <div class="item_image_text">
                                        <div>
                                            <p class="item_p_1">
                                                10 300 грн
                                            </p>
                                            <p class="item_p_2">
                                                за 1 особу
                                            </p>
                                        </div>
                                        <button>
                                            Детальніше
                                        </button>
                                    </div>
                                </div>
                                <div class="item_info">
                                    <p class="item_info_p_1">
                                        Seazone Hotel
                                    </p>
                                    <p class="item_info_p_2">
                                        Украина , Затока
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tour">
                        <div class="tour_block_items">
                            <div class="tour_item">
                                <div class="item_image">
                                    <img src="../img/169.jpg"/>
                                    <div class="item_image_text">
                                        <div>
                                            <p class="item_p_1">
                                                10 300 грн
                                            </p>
                                            <p class="item_p_2">
                                                за 1 особу
                                            </p>
                                        </div>
                                        <button>
                                            Детальніше
                                        </button>
                                    </div>
                                </div>
                                <div class="item_info">
                                    <p class="item_info_p_1">
                                        Seazone Hotel
                                    </p>
                                    <p class="item_info_p_2">
                                        Украина , Затока
                                    </p>
                                </div>
                            </div>
                            <div class="tour_item">
                                <div class="item_image">
                                    <img src="../img/169.jpg"/>
                                    <div class="item_image_text">
                                        <div>
                                            <p class="item_p_1">
                                                10 300 грн
                                            </p>
                                            <p class="item_p_2">
                                                за 1 особу
                                            </p>
                                        </div>
                                        <button>
                                            Детальніше
                                        </button>
                                    </div>
                                </div>
                                <div class="item_info">
                                    <p class="item_info_p_1">
                                        Seazone Hotel
                                    </p>
                                    <p class="item_info_p_2">
                                        Украина , Затока
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="question">
                        <div>
                            <p class="question_text_1">
                                Не змогли обрати найкращій тур?
                            </p>
                            <p class="question_text_2">
                                Залиште повідомлення і ми знайдемо для Вас райський відпочинок
                            </p>
                        </div>
                        <div>
                            <form class="question_call" method="post">
                                @csrf
                                <input type="text" name="name" placeholder="Ваше ім'я..">
                                <input type="text" name="phone" placeholder="Телефон..">
                                <button type="submit">Відправити</button>
                            </form>
                        </div>
                    </div>

                    <div class="tour">
                        <div class="tour_block_items">
                            <div class="tour_item">
                                <div class="item_image">
                                    <img src="../img/169.jpg"/>
                                    <div class="item_image_text">
                                        <div>
                                            <p class="item_p_1">
                                                10 300 грн
                                            </p>
                                            <p class="item_p_2">
                                                за 1 особу
                                            </p>
                                        </div>
                                        <button>
                                            Детальніше
                                        </button>
                                    </div>
                                </div>
                                <div class="item_info">
                                    <p class="item_info_p_1">
                                        Seazone Hotel
                                    </p>
                                    <p class="item_info_p_2">
                                        Украина , Затока
                                    </p>
                                </div>
                            </div>
                            <div class="tour_item">
                                <div class="item_image">
                                    <img src="../img/169.jpg"/>
                                    <div class="item_image_text">
                                        <div>
                                            <p class="item_p_1">
                                                10 300 грн
                                            </p>
                                            <p class="item_p_2">
                                                за 1 особу
                                            </p>
                                        </div>
                                        <button>
                                            Детальніше
                                        </button>
                                    </div>
                                </div>
                                <div class="item_info">
                                    <p class="item_info_p_1">
                                        Seazone Hotel
                                    </p>
                                    <p class="item_info_p_2">
                                        Украина , Затока
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
