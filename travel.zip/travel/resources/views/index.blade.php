@extends('main')
{{--{{$p = \App\Question::all()->find(1)}}--}}
{{--<h1>{{"$p->name"}}</h1>--}}
@section('library')
    @if(isset($page->lib))
        {{ "../css/$page->lib.css" }}
    @else
        {{ "../css/landing.css" }}
    @endif
@endsection
@section('content')
    @if(isset($page->lib))
        @include($page->page)
    @else
        @include('landing')
    @endif
@endsection
