<div class="body">
    <div class="name_hotel">
        <h4>Monna Roza Garden Resort</h4>
    </div>
    <div class="stars">
        <img src="../img/shapes-and-symbols.svg">
        <img src="../img/shapes-and-symbols.svg">
        <img src="../img/shapes-and-symbols.svg">
        <img src="../img/shapes-and-symbols.svg">
        <p>Турция, Кемер</p>
    </div>


</div>
<div class="photo_hotel">
    <div class="photo">
        <div class="photo_img">
            <img src="../img/photo_2020-05-15_19-59-52.jpg">
        </div>
        <div class="photo_img">
            <img src="../img/photo_2020-05-15_20-00-03.jpg">
        </div>
        <div class="photo_img">
            <img src="../img/photo_2020-05-15_20-00-06.jpg">
        </div>

    </div>


    <div class="photo_key">
        <div id="btn_treang_1"></div>
        <p>1 з 10</p>
        <div id="btn_treang_2"></div>
    </div>

</div>

<div class="body">
    <div class="fitch">
        <!--            <div>-->
        <div class="fitch_text">
            <p>Водяні гірки</p>
        </div>
        <div class="fitch_text">
            <p>Відкритий басейн</p>
        </div>
        <!--            </div>-->
        <!--            <div>-->
        <div class="fitch_text">
            <p>Безкоштовний Wi-Fi</p>
        </div>
        <div class="fitch_text">
            <p>Кращі пропозиції</p>
        </div>
        <!--            </div>-->

    </div>

    <div class="description">
        <h4 class="description_h4">Опис</h4>
        <p>Якісний готель для сімейного відпочинку з великою кількістю басейнів і водних гірок.<br>
            Готель знаходиться всього в 7 км від аеропорту Хургади, в 3 км від найбільшого<br>
            торгового центру курорту Senzo Mall і в 14 км від центру міста.<br>
            <br>
            Готель побудований в 2011 році, загальна площа 12000 м2.<br>
            Готель складається з трьох 3-поверхових будівель:<br>
            167 standard room (з них 2 номер для інвалідів, макс. 2 + 2 чол., 25 м2),<br>
            9 однокімнатних family room (макс. 3 + 1,35 м2).<br>
        </p>

    </div>
</div>
<div class="fon_search">
    <div class="search_h4"> <h4>Тури в готель</h4></div>
    <div class="search">
        <div class="search_text">
            <div>
                <p>
                    Оберіть оптимальний варіант, саме для вас
                </p>
            </div>
            <table>
                <tr>
                    <td>
                        <div>
                            <img src="../img/people%20(2).png">
                            <p class="search_p_1">Виїзд з:</p>
                            <p class="search_p_2">Києва</p>
                        </div>
                    </td>
                    <td>
                        <div>
                            <img src="../img/interface.png">
                            <p class="search_p_1">Дата, тривалість:</p>
                            <p class="search_p_2">15.05 - 24.05, 7 - 10 ночей</p>
                        </div>
                    </td>
                    <td>
                        <div>
                            <img src="../img/eat.png">
                            <p class="search_p_1">Тип харчування:</p>
                            <p class="search_p_2">Будь-яке харчування</p>
                        </div>
                    </td>
                    <td>
                        <div>
                            <img src="../img/people.png">
                            <p class="search_p_1">Хто їде:</p>
                            <p class="search_p_2">2 дорослих</p>
                        </div>
                    </td>
                    <td class="td_speshil">
                        <a>Пошук</a>
                    </td>
                </tr>
            </table>
        </div>
    </div>
</div>
<div class="body">

    <div class="find_tour">
        <h4 class="find_tour_h4">Знайдено 3 тури</h4>
        <div class="find_tour_text">
            <table>
                <tr>
                    <td>
                        <div>
                            <p class="find_search_p_1">Відправлення/Прибуття:</p>
                            <p class="find_search_p_2">
                                01.07 виліт <br>
                                08.07 приліт назад
                            </p>
                        </div>

                    </td>
                    <td>
                        <div>
                            <p class="find_search_p_1">Кількість ночей:</p>
                            <p class="find_search_p_2">7 ночей</p>
                        </div>
                    </td>
                    <td>
                        <div>
                            <p class="find_search_p_1">Тип харчування:</p>
                            <p class="find_search_p_2">All Inclusive</p>
                        </div>
                    </td>
                    <td>
                        <div>
                            <p class="find_search_p_1">Номер  для:</p>
                            <p class="find_search_p_2">2 дорослих</p>
                        </div>
                    </td>
                    <td>
                        <div>
                            <p class="find_search_p_1">Кімната:</p>
                            <p class="find_search_p_2">Standard Room</p>
                        </div>
                    </td>
                    <td class="td_speshil_find">
                        <div>
                            <p>
                                23 437 UAH<br>
                                на двох
                            </p>
                            <a>Забронювати</a>
                        </div>
                    </td>
                </tr>
            </table>

        </div>
        <div class="find_tour_text">
            <table>
                <tr>
                    <td>
                        <p class="find_search_p_1">Відправлення/Прибуття:</p>
                        <p class="find_search_p_2">
                            01.07 виліт <br>
                            08.07 приліт назад
                        </p>

                    </td>
                    <td>
                        <p class="find_search_p_1">Кількість ночей:</p>
                        <p class="find_search_p_2">7 ночей</p>
                    </td>
                    <td>
                        <div>
                            <p class="find_search_p_1">Тип харчування:</p>
                            <p class="find_search_p_2">All Inclusive</p>
                        </div>
                    </td>
                    <td>
                        <div>
                            <p class="find_search_p_1">Номер  для:</p>
                            <p class="find_search_p_2">2 дорослих</p>
                        </div>
                    </td>
                    <td>
                        <div>
                            <p class="find_search_p_1">Кімната:</p>
                            <p class="find_search_p_2">Standard Room</p>
                        </div>
                    </td>
                    <td class="td_speshil_find">
                        <div>
                            <p>
                                23 437 UAH<br>
                                на двоих
                            </p>
                            <a>Забронювати</a>
                        </div>
                    </td>
                </tr>
            </table>

        </div>
        <div class="find_tour_text">
            <table>
                <tr>
                    <td>
                        <p class="find_search_p_1">Відправлення/Прибуття:</p>
                        <p class="find_search_p_2">
                            01.07 виліт <br>
                            08.07 приліт назад
                        </p>

                    </td>
                    <td>
                        <p class="find_search_p_1">Кількість ночей:</p>
                        <p class="find_search_p_2">7 ночей</p>
                    </td>
                    <td>
                        <div>
                            <p class="find_search_p_1">Тип харчування:</p>
                            <p class="find_search_p_2">All Inclusive</p>
                        </div>
                    </td>
                    <td>
                        <div>
                            <p class="find_search_p_1">Номер  для:</p>
                            <p class="find_search_p_2">2 дорослих</p>
                        </div>
                    </td>
                    <td>
                        <div>
                            <p class="find_search_p_1">Кімната:</p>
                            <p class="find_search_p_2">Standard Room</p>
                        </div>
                    </td>
                    <td class="td_speshil_find">
                        <div>
                            <p>
                                23 437 UAH<br>
                                на двоих
                            </p>
                            <a>Забронювати</a>
                        </div>
                    </td>
                </tr>
            </table>

        </div>
    </div>
</div>
