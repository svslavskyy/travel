@extends('html_searching')
@section('filter_check')
    @if(isset($filter))
        <div class="filter_box_name">
            @foreach($filter as $key => $types )
                @foreach($types as $item)
                    <div class="right_filter_boxing">
                        <p>{{$item}}</p>
                        <button class="btn_wrong"></button>
                    </div>
                @endforeach
            @endforeach
        </div>
    @endif
@endsection


@section('filter_left')
    <form action="/searching/searching">
        <div class="left_content">
            <div class="left_class">
                <form>
                    <div class="left_items_type">
                        <p>Куди</p>
                        <button class="type_on"></button>
                        <button class="type_off"></button>
                    </div>
                    <div>
                        <label class="left_item">
                            @if($filter["country"])
                                <input class="checkbox" type="checkbox" name="country[]" value="all_country" checked>
                            @else
                                <input class="checkbox" type="checkbox" name="country[]" value="all_country">
                            @endif
                            <span class="fake-checkbox"></span> Всі країни
                        </label>
                        <label class="left_item">
                            <input class="checkbox" type="checkbox" name="country[]" value="Egypt">
                            <span class="fake-checkbox"></span> Египет
                        </label>
                        <label class="left_item">
                            <input class="checkbox" type="checkbox" name="country[]" value="Spain">
                            <span class="fake-checkbox"></span> Іспанія
                        </label>
                        <label class="left_item">
                            <input class="checkbox" type="checkbox" name="country[]" value="Greece">
                            <span class="fake-checkbox"></span> Греція
                        </label>
                        <label class="left_item">
                            <input class="checkbox" type="checkbox"  name="country[]" value="Italy">
                            <span class="fake-checkbox"></span> Італія
                        </label>
                    </div>
                </form>
            </div>
            <div class="left_class">
                <div class="left_items_type">
                    <p>Місто відправлення</p>
                    <button class="type_on"></button>
                    <button class="type_off"></button>
                </div>
                <label class="left_item">
                    <input class="checkbox" type="checkbox" name="city[]" value="all_city">
                    <span class="fake-checkbox"></span> Всі міста
                </label>
                <label class="left_item">
                    <input class="checkbox" type="checkbox" name="city[]" value="Kiev">
                    <span class="fake-checkbox"></span> Київ
                </label>
                <label class="left_item">
                    <input class="checkbox" type="checkbox" name="city[]" value="Lviv">
                    <span class="fake-checkbox"></span> Львів
                </label>
                <label class="left_item">
                    <input class="checkbox" type="checkbox" name="city[]" value="Odessa">
                    <span class="fake-checkbox"></span> Одеса
                </label>
                <label class="left_item" >
                    <input class="checkbox" type="checkbox" name="city[]" value="Dnipro">
                    <span class="fake-checkbox"></span> Дніпро
                </label>
            </div>
            <div class="left_class">

                <div class="left_items_type">
                    <p>Тривалість</p>
                    <button class="type_on"></button>
                    <button class="type_off"></button>
                </div>
                <label class="left_item">
                    <input class="checkbox" type="checkbox" name="duration[]" value="all_duration">
                    <span class="fake-checkbox"></span> Всі дні
                </label>
                <label class="left_item">
                    <input class="checkbox" type="checkbox" name="duration[]" value="3">
                    <span class="fake-checkbox"></span> 3 дні
                </label>
                <label class="left_item">
                    <input class="checkbox" type="checkbox" name="duration[]" value="7">
                    <span class="fake-checkbox"></span> 7 днів
                </label>
                <label class="left_item" >
                    <input class="checkbox" type="checkbox" name="duration[]" value="9">
                    <span class="fake-checkbox"></span> 9 днів
                </label>
                <label class="left_item" >
                    <input class="checkbox" type="checkbox" name="duration[]" value="14">
                    <span class="fake-checkbox"></span> 14 днів
                </label>
            </div>
            <div class="left_class">
                <div class="left_items_type">
                    <p>Вартість</p>
                    <button class="type_on"></button>
                    <button class="type_off"></button>
                </div>
                <label class="left_item">
                    <input class="checkbox" type="checkbox" name="price[]" value="all_price">
                    <span class="fake-checkbox"></span> Будь-яка
                </label>
                <label class="left_item">
                    <input class="checkbox" type="checkbox" name="price[]" value="10000">
                    <span class="fake-checkbox"></span> до 10000 грн
                </label>
                <label class="left_item">
                    <input class="checkbox" type="checkbox" name="price[]" value="15000">
                    <span class="fake-checkbox"></span> до 15000 грн
                </label>
                <label class="left_item" >
                    <input class="checkbox" type="checkbox" name="price[]" value="30000">
                    <span class="fake-checkbox"></span> до 30000 грн
                </label>
                <label class="left_item" >
                    <input class="checkbox" type="checkbox" name="price[]" value="any">
                    <span class="fake-checkbox"></span> понад 30000 грн
                </label>
            </div>
            <button type="submit">Застосувати</button>

        </div>
    </form>

@endsection
