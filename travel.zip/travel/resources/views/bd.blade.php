@foreach($name as $names)
    @foreach($names as $n)
        <h1>{{$n}}</h1>
        @endforeach
@endforeach
