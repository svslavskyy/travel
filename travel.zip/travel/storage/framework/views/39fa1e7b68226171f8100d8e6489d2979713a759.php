<?php $__env->startSection('library'); ?>
    <?php if(isset($obj->lib)): ?>
        <?php echo e(asset("css/$obj->lib.css")); ?>

    <?php else: ?>
        <?php echo e(asset("css/landing.css")); ?>

    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php if(isset($obj->lib)): ?>
        <?php echo $__env->make($obj->page, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php else: ?>
        <?php echo $__env->make('landing', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Курсовая веб\travel\resources\views/index.blade.php ENDPATH**/ ?>