<div class="body">

    <div class="why">
        <h4>Пошук турів</h4>
        <div class="why_text">
            <div class="left_small">
                <button class="left_small_filter">Фільтр</button>
                <button class="left_small_cancel">Очистити</button>
            </div>
            <div class="left">
                <h5>Фільтр</h5>
                <form>
                    <div class="left_content">

                        <div class="left_class">
                            <form>
                                <div class="left_items_type">
                                    <p>Куди</p>
                                    <button class="type_on"></button>
                                    <button class="type_off"></button>
                                </div>
                                <div>
                                    <label class="left_item">
                                        <input class="checkbox" type="checkbox" name="all_country">
                                        <span class="fake-checkbox"></span> Всі країни
                                    </label>
                                    <label class="left_item">
                                        <input class="checkbox" type="checkbox" name="Egypt">
                                        <span class="fake-checkbox"></span> Египет
                                    </label>
                                    <label class="left_item">
                                        <input class="checkbox" type="checkbox" name="Spain">
                                        <span class="fake-checkbox"></span> Іспанія
                                    </label>
                                    <label class="left_item">
                                        <input class="checkbox" type="checkbox" name="Greece">
                                        <span class="fake-checkbox"></span> Греція
                                    </label>
                                    <label class="left_item">
                                        <input class="checkbox" type="checkbox" name="Italy">
                                        <span class="fake-checkbox"></span> Італія
                                    </label>
                                </div>
                            </form>
                        </div>
                        <div class="left_class">
                            <form>
                                <div class="left_items_type">
                                    <p>Місто відправлення</p>
                                    <button class="type_on"></button>
                                    <button class="type_off"></button>
                                </div>
                                <label class="left_item">
                                    <input class="checkbox" type="checkbox">
                                    <span class="fake-checkbox"></span> Всі міста
                                </label>
                                <label class="left_item">
                                    <input class="checkbox" type="checkbox">
                                    <span class="fake-checkbox"></span> Київ
                                </label>
                                <label class="left_item">
                                    <input class="checkbox" type="checkbox">
                                    <span class="fake-checkbox"></span> Львів
                                </label>
                                <label class="left_item">
                                    <input class="checkbox" type="checkbox">
                                    <span class="fake-checkbox"></span> Одеса
                                </label>
                                <label class="left_item">
                                    <input class="checkbox" type="checkbox">
                                    <span class="fake-checkbox"></span> Дніпро
                                </label>
                            </form>
                        </div>
                        <div class="left_class">

                            <div class="left_items_type">
                                <p>Тривалість</p>
                                <button class="type_on"></button>
                                <button class="type_off"></button>
                            </div>
                            <label class="left_item">
                                <input class="checkbox" type="checkbox">
                                <span class="fake-checkbox"></span> Всі дні
                            </label>
                            <label class="left_item">
                                <input class="checkbox" type="checkbox">
                                <span class="fake-checkbox"></span> 3 дні
                            </label>
                            <label class="left_item">
                                <input class="checkbox" type="checkbox">
                                <span class="fake-checkbox"></span> 7 днів
                            </label>
                            <label class="left_item" >
                                <input class="checkbox" type="checkbox" name="">
                                <span class="fake-checkbox"></span> 9 днів
                            </label>
                            <label class="left_item" >
                                <input class="checkbox" type="checkbox" name="">
                                <span class="fake-checkbox"></span> 14 днів
                            </label>
                        </div>
                        <div class="left_class">

                            <div class="left_items_type">
                                <p>Вартість</p>
                                <button class="type_on"></button>
                                <button class="type_off"></button>
                            </div>
                            <label class="left_item">
                                <input class="checkbox" type="checkbox">
                                <span class="fake-checkbox"></span> Всі пропозиції
                            </label>
                            <label class="left_item">
                                <input class="checkbox" type="checkbox">
                                <span class="fake-checkbox"></span> до 10000 грн
                            </label>
                            <label class="left_item">
                                <input class="checkbox" type="checkbox">
                                <span class="fake-checkbox"></span> до 15000 грн
                            </label>
                            <label class="left_item" >
                                <input class="checkbox" type="checkbox" name="">
                                <span class="fake-checkbox"></span> до 30000 грн
                            </label>
                            <label class="left_item" >
                                <input class="checkbox" type="checkbox" name="">
                                <span class="fake-checkbox"></span> понад 30000 грн
                            </label>
                        </div>
                        <button type="submit">Застосувати</button>

                    </div>
                </form>
            </div>


            <div class="right">
                <div class="filter_box_name">
                    <div class="right_filter_boxing">
                        <p>Єгипет</p>
                        <button class="btn_wrong"></button>
                    </div>
                    <div class="right_filter_boxing">
                        <p>Київ</p>
                        <button class="btn_wrong"></button>
                    </div>
                    <div class="right_filter_boxing">
                        <p>Турція</p>
                        <button class="btn_wrong"></button>
                    </div>
                </div>

                <div class="right_tour">
                    <div class="tour">
                        <!--                            <div class="tour_block">-->
                        <div class="tour_block_items">
                            <div class="tour_item">
                                <div class="item_image">
                                    <img src="../img/169.jpg"/>
                                    <div class="item_image_text">
                                        <div>
                                            <p class="item_p_1">
                                                10 300 грн
                                            </p>
                                            <p class="item_p_2">
                                                за 1 особу
                                            </p>
                                        </div>
                                        <button>
                                            Детальніше
                                        </button>
                                    </div>
                                </div>
                                <div class="item_info">
                                    <p class="item_info_p_1">
                                        Seazone Hotel
                                    </p>
                                    <p class="item_info_p_2">
                                        Украина , Затока
                                    </p>
                                </div>
                            </div>
                            <div class="tour_item">
                                <div class="item_image">
                                    <img src="../img/169.jpg"/>
                                    <div class="item_image_text">
                                        <div>
                                            <p class="item_p_1">
                                                10 300 грн
                                            </p>
                                            <p class="item_p_2">
                                                за 1 особу
                                            </p>
                                        </div>
                                        <button>
                                            Детальніше
                                        </button>
                                    </div>
                                </div>
                                <div class="item_info">
                                    <p class="item_info_p_1">
                                        Seazone Hotel
                                    </p>
                                    <p class="item_info_p_2">
                                        Украина , Затока
                                    </p>
                                </div>
                            </div>
                        </div>
                        <!--                            </div>-->
                    </div>
                    <div class="tour">
                        <!--                            <div class="tour_block">-->
                        <div class="tour_block_items">
                            <div class="tour_item">
                                <div class="item_image">
                                    <img src="../img/169.jpg"/>
                                    <div class="item_image_text">
                                        <div>
                                            <p class="item_p_1">
                                                10 300 грн
                                            </p>
                                            <p class="item_p_2">
                                                за 1 особу
                                            </p>
                                        </div>
                                        <button>
                                            Детальніше
                                        </button>
                                    </div>
                                </div>
                                <div class="item_info">
                                    <p class="item_info_p_1">
                                        Seazone Hotel
                                    </p>
                                    <p class="item_info_p_2">
                                        Украина , Затока
                                    </p>
                                </div>
                            </div>
                            <div class="tour_item">
                                <div class="item_image">
                                    <img src="../img/169.jpg"/>
                                    <div class="item_image_text">
                                        <div>
                                            <p class="item_p_1">
                                                10 300 грн
                                            </p>
                                            <p class="item_p_2">
                                                за 1 особу
                                            </p>
                                        </div>
                                        <button>
                                            Детальніше
                                        </button>
                                    </div>
                                </div>
                                <div class="item_info">
                                    <p class="item_info_p_1">
                                        Seazone Hotel
                                    </p>
                                    <p class="item_info_p_2">
                                        Украина , Затока
                                    </p>
                                </div>
                            </div>
                        </div>
                        <!--                            </div>-->
                    </div>
                    <div class="question">
                        <div>
                            <p class="question_text_1">
                                Не змогли обрати найкращій тур?
                            </p>
                            <p class="question_text_2">
                                Залиште повідомлення і ми знайдемо для Вас райський відпочинок
                            </p>
                        </div>
                        <div>
                            <form class="question_call">
                                <input type="text" name="name" placeholder="Ваше ім'я..">
                                <input type="text" name="phone" placeholder="Телефон..">
                                <button type="submit">Відправити</button>
                            </form>
                        </div>
                    </div>

                    <div class="tour">
                        <!--                            <div class="tour_block">-->
                        <div class="tour_block_items">
                            <div class="tour_item">
                                <div class="item_image">
                                    <img src="../img/169.jpg"/>
                                    <div class="item_image_text">
                                        <div>
                                            <p class="item_p_1">
                                                10 300 грн
                                            </p>
                                            <p class="item_p_2">
                                                за 1 особу
                                            </p>
                                        </div>
                                        <button>
                                            Детальніше
                                        </button>
                                    </div>
                                </div>
                                <div class="item_info">
                                    <p class="item_info_p_1">
                                        Seazone Hotel
                                    </p>
                                    <p class="item_info_p_2">
                                        Украина , Затока
                                    </p>
                                </div>
                            </div>
                            <div class="tour_item">
                                <div class="item_image">
                                    <img src="../img/169.jpg"/>
                                    <div class="item_image_text">
                                        <div>
                                            <p class="item_p_1">
                                                10 300 грн
                                            </p>
                                            <p class="item_p_2">
                                                за 1 особу
                                            </p>
                                        </div>
                                        <button>
                                            Детальніше
                                        </button>
                                    </div>
                                </div>
                                <div class="item_info">
                                    <p class="item_info_p_1">
                                        Seazone Hotel
                                    </p>
                                    <p class="item_info_p_2">
                                        Украина , Затока
                                    </p>
                                </div>
                            </div>
                        </div>
                        <!--                            </div>-->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\Курсовая веб\travel\resources\views/searching.blade.php ENDPATH**/ ?>